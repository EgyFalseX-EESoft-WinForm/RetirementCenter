namespace RetirementCenter
{
    partial class dsTeachersUnionViewsDataContext
    {
    }
}
