﻿namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{
}
namespace RetirementCenter.DataSources
{


    public partial class dsRetirementCenter
    {
    }
}

namespace RetirementCenter.DataSources.dsRetirementCenterTableAdapters {
    
    
    public partial class TBLReSarfWarasaTableAdapter {
    }
}
